/* $Id: H:/drh/idioms/book/RCS/table.doc,v 1.13 1997/10/27 23:10:11 drh Exp $ */
#include <stdio.h>
extern int getword(FILE *fp, char *buf, int size,
	int first(int c), int rest(int c));
